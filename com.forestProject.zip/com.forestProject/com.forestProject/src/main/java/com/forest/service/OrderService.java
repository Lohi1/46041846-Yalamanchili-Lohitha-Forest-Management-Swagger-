package com.forest.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.fms.exceptions.InvalidOperation;
import com.forest.model.Order;
import com.forest.repository.OrderRepository;
import com.forest.validations.OrderValidation;

@Service
public class OrderService {
	@Autowired
	private OrderRepository OrderRepository;
	
	public Order getOrderByorderNumber(Integer orderNumber)
	{
		try 
		{
			return OrderRepository.findById(orderNumber).get();
		}
		catch(InvalidOperation ie)
		{
			ie.printStackTrace();
			return null;
		}
	}
	public Order addOrder(Order Order) {
		
		
		if(Order!=null && Order.getDeliveryDate().matches(OrderValidation.dateregex))
		{
			return OrderRepository.save(Order);
		}
		else
		{	
			throw new InvalidOperation("cannot find Orders");
			
		}
	
	}
	public Order updateOrder(Order Order) {
		if( Order!=null && Order.getDeliveryDate().matches(OrderValidation.dateregex))
		{
			OrderRepository.save(Order);
			return Order;
		}
		else
		{
			throw new InvalidOperation("Order not updated");
			
		}
	}
	public boolean deleteOrderbyorderNumber(Integer orderNumber) 
	{
		if(orderNumber!=null)
		{
			OrderRepository.deleteById(orderNumber);
			return true;
			
		}
		else
		{
			throw new InvalidOperation("Order cannot deleted");
			
		}
	
	}
	public List<Order> getAllOrders() {
		List<Order> Orderlist=new ArrayList<Order>();
		OrderRepository.findAll().forEach(order->Orderlist.add(order));
		return Orderlist;
	
	}	
}
