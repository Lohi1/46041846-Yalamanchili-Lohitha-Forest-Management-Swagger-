package com.forest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import com.forest.model.Land;
import com.forest.service.LandService;

@Controller
@RequestMapping("/Land")
public class LandController {
	@Autowired
	private LandService LandService;
	
	@GetMapping("/{landId}")
	public @ResponseBody Land getLandBylandId(@PathVariable Integer landId)
	{
		return LandService.getLandBylandId(landId);
		
	}
	@PostMapping("/")
	public @ResponseBody Land addLand(@RequestBody Land Land)
	{
		return LandService.addLand(Land);
	}
	@PutMapping("/")
	public @ResponseBody Land updateLand(@RequestBody Land Land)
	{
		return LandService.updateLand(Land);
		
	}
	
	@DeleteMapping("/{landId}")
	public @ResponseBody boolean deleteLandbylandId(@PathVariable Integer landId)
	{
		return LandService.deleteLandbylandId(landId);
	}
	
	@GetMapping("/")
	public @ResponseBody List<Land> getAllLand()
	{
		List<Land> Landlist=LandService.getAllLands();
		return Landlist;
	}
	
	
	
	
	
	
}
