package com.cg.fms.exceptions;

public class InvalidOperation extends RuntimeException{
	public InvalidOperation(String msg)
	{
		super(msg);
	}

}
