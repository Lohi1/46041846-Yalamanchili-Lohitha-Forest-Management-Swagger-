package com.forest.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.forest.model.Land;

public interface ILandService 
{
	Land getLandBylandId(@PathVariable Integer landId);
	
	Land addLand(@RequestBody Land Land);
	
	Land updateLand(@RequestBody Land Land);
	
	 boolean deleteLandbylandId(@PathVariable Integer landId);
	
	 List<Land> getAllLand();
	
}
